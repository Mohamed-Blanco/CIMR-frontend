


export class Competence {

    constructor() {

    }

    id !: number;
    titrecompetence !: String;

}