export class departement {

    id!: number;
    nbr_collaborateurs!: string | null;
    titre!: string | null;
    description !: string;

    constructor() { }

}