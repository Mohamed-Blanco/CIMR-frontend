import { Collaborateur } from "./collaborateur";


export interface ProjetCount {

    collaborateur: Collaborateur;
    projetCount: number;
}