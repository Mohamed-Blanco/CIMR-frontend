import { Component } from '@angular/core';

@Component({
  selector: 'app-completer-profil',
  templateUrl: './completer-profil.component.html',
  styleUrl: './completer-profil.component.css'
})
export class CompleterProfilComponent {

}
