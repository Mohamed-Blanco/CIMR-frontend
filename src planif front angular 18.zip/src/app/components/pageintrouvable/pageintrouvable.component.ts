import { Component } from '@angular/core';

@Component({
  selector: 'app-pageintrouvable',
  templateUrl: './pageintrouvable.component.html',
  styleUrl: './pageintrouvable.component.css'
})
export class PageintrouvableComponent {

}
