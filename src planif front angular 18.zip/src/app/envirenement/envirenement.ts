export const envirenement = {
  production: false,
  apiBaseUrl: 'http://localhost:8090',
};
