export const envirenement = {
  production: true,
  apiBaseUrl: 'http://localhost:8090',
};
